<?php
$module_name = 'tt_ServiceTrials';
$OBJECT_NAME = 'TT_SERVICETRIALS';
$listViewDefs [$module_name] = 
array (
  'TT_SERVICETRIALS_NUMBER' => 
  array (
    'width' => '5%',
    'label' => 'LBL_NUMBER',
    'link' => true,
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_SUBJECT',
    'default' => true,
    'link' => true,
  ),
  'STATUS' => 
  array (
    'width' => '10%',
    'label' => 'LBL_STATUS',
    'default' => true,
  ),
  'PERIOD_START' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PERIOD_START',
    'default' => true,
  ),
  'PERIOD_END' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PERIOD_END',
    'default' => true,
  ),
  'PRIORITY' => 
  array (
    'width' => '10%',
    'label' => 'LBL_PRIORITY',
    'default' => true,
  ),
);
?>
