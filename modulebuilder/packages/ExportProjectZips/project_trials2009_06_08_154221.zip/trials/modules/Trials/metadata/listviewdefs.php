<?php
$module_name = 'tr_Trials';
$OBJECT_NAME = 'TR_TRIALS';
$listViewDefs [$module_name] = 
array (
  'TR_TRIALS_NUMBER' => 
  array (
    'width' => '5%',
    'label' => 'LBL_NUMBER',
    'link' => true,
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_SUBJECT',
    'default' => true,
    'link' => true,
  ),
  'TESTING_BANDWIDTH' => 
  array (
    'width' => '10%',
    'label' => 'LBL_TESTING_BANDWIDTH',
    'default' => true,
  ),
  'START_DATE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_START_DATE',
    'default' => true,
  ),
  'END_DATE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_END_DATE',
    'default' => true,
  ),
  'PRIORITY' => 
  array (
    'width' => '9%',
    'label' => 'LBL_PRIORITY',
    'default' => true,
  ),
  'STATUS' => 
  array (
    'width' => '10%',
    'label' => 'LBL_STATUS',
    'default' => true,
  ),
  'CREATED_BY_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_CREATED',
    'default' => true,
  ),
  'RESOLUTION' => 
  array (
    'width' => '10%',
    'label' => 'LBL_RESOLUTION',
    'default' => false,
  ),
);
?>
